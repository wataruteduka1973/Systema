let currentData = [];
let currentMedianPrice = 0;
let watchedByUrl = new Map();

document.addEventListener("DOMContentLoaded", function () {

    const searchInput = document.getElementById('search');

    // Enterキーで検索
    searchInput.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            TargetSearch();
        }
    });

    // 人気ワード取得・ボタン生成
    fetch('/taskle/get_popular_words?top=10')
        .then(res => res.json())
        .then(data => {
            const area = document.getElementById('popularWordsBtnGroup');
            area.innerHTML = '';
            (data.words || []).forEach(word => {
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'btn btn-outline-danger btn-sm';
                btn.textContent = word;
                btn.onclick = function () {
                    const searchInput = document.getElementById('search');
                    if (searchInput.value) {
                        searchInput.value += ' ' + word;
                    } else {
                        searchInput.value = word;
                    }
                    searchInput.focus();
                };
                area.appendChild(btn);
            });

        });

    loadWatchlist();

});
// 検索ボタンのクリックイベント
function TargetSearch() {
    const searchKeyword = document.getElementById("search").value.trim();
    if (!searchKeyword) {
        alert('検索キーワードを入力してください');
        return;
    }
    const params = new URLSearchParams({
        keyword: searchKeyword,
    });

    const spinner = document.getElementById('searchSpinner');
    const button = document.getElementById('button-search');
    spinner.style.display = 'inline-block';
    button.disabled = true;
    fetch(`/taskle/complex_market_data?${params.toString()}`)
        .then(response => {
            if (!response.ok) {
                if (response.status === 400 || response.status === 500) {
                    return response.text().then(text => {
                        document.open();
                        document.write(text);
                        document.close();
                        throw new Error(`Error page rendered: ${response.status}`);
                    });
                }
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(result => {
            const recommendations = result.recommend_items || [];
            if (recommendations.length && recommendations.some(item => !item.buyDecision || !item.condition)) {
                throw new Error('SERVER_RESTART_REQUIRED');
            }
            if (typeof result.medianPrice !== "undefined") {
                currentMedianPrice = Number(result.medianPrice) || 0;
                document.getElementById('medianPrice').textContent = Math.round(result.medianPrice).toLocaleString();
                document.getElementById('medianPriceBox').style.display = "block";
            } else {
                document.getElementById('medianPriceBox').style.display = "none";
            }
            currentData = recommendations;
            updateTable(currentData);
        })
        .catch(error => {
            console.error('検索エラー:', error);
            if (error.message === 'SERVER_RESTART_REQUIRED') {
                alert('更新前のサーバーが動作しています。Systemaを停止し、run_systema.batから再起動してください。');
            } else {
                alert('検索に失敗しました');
            }
        })
        .finally(() => {
            spinner.style.display = 'none';
            button.disabled = false;
        });
}

function updateTable(data) {
    const tableBody = document.getElementById("dataTable").getElementsByTagName("tbody")[0];
    tableBody.innerHTML = "";

    data.forEach(item => {
        const row = tableBody.insertRow();
        const productNameCell = row.insertCell(0);
        productNameCell.textContent = item.name || 'N/A';
        const conditionCell = row.insertCell(1);
        conditionCell.appendChild(createConditionBadge(item));
        const currentPriceCell = row.insertCell(2);
        currentPriceCell.textContent = item.price !== undefined && item.price !== null ? item.price.toLocaleString() : 'N/A';
        const decisionCell = row.insertCell(3);
        decisionCell.appendChild(createDecisionBadge(item.buyDecision));
        if (item.buyDecision && item.buyDecision.reason) {
            const reason = document.createElement('div');
            reason.className = 'small text-muted mt-1';
            reason.textContent = item.buyDecision.reason;
            decisionCell.appendChild(reason);
        }
        const biddingCell = row.insertCell(4);
        biddingCell.textContent = item.bidding !== undefined ? item.bidding : 'N/A';
        const remainingTimeCell = row.insertCell(5);
        remainingTimeCell.textContent = item.remainingTime || 'N/A';
        const productURLCell = row.insertCell(6);
        const link = document.createElement("a");
        link.href = item.url || '#';
        link.textContent = "商品リンクURL";
        link.target = "_blank";
        link.rel = "noopener noreferrer";
        productURLCell.appendChild(link);
        const watchCell = row.insertCell(7);
        watchCell.appendChild(createWatchButton(item));
    });
}

function createConditionBadge(item) {
    const badge = document.createElement('span');
    const color = item.condition === 'junk' ? 'bg-danger'
        : item.condition === 'new' ? 'bg-success'
            : item.condition === 'used' ? 'bg-primary' : 'bg-secondary';
    badge.className = `badge ${color}`;
    badge.textContent = item.conditionLabel || '未分類';
    return badge;
}

function createDecisionBadge(decision) {
    const badge = document.createElement('span');
    const status = decision ? decision.status : 'insufficient';
    const color = status === 'strong_buy' ? 'bg-success'
        : status === 'buy' ? 'bg-primary'
            : status === 'consider' ? 'bg-warning text-dark'
                : status === 'caution' ? 'bg-danger' : 'bg-secondary';
    badge.className = `badge ${color}`;
    badge.textContent = decision ? `${decision.label} (${decision.score})` : '判定材料不足';
    return badge;
}

function createWatchButton(item) {
    const button = document.createElement('button');
    button.type = 'button';
    const watched = watchedByUrl.get(item.url);
    button.className = watched ? 'btn btn-sm btn-outline-danger' : 'btn btn-sm btn-primary';
    button.textContent = watched ? 'ウォッチ解除' : 'ウォッチリストへ追加';
    button.addEventListener('click', () => watched ? removeWatchItem(watched.id) : addWatchItem(item));
    return button;
}

async function loadWatchlist() {
    const empty = document.getElementById('watchlistEmpty');
    try {
        const response = await fetch('/taskle/watchlist');
        if (response.status === 404) throw new Error('SERVER_RESTART_REQUIRED');
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const result = await response.json();
        empty.className = 'alert alert-secondary';
        empty.textContent = 'ウォッチ中の商品はありません。';
        watchedByUrl = new Map((result.items || []).map(item => [item.url, item]));
        renderWatchlist(result.items || []);
        updateTable(currentData);
    } catch (error) {
        console.error('ウォッチリスト取得エラー:', error);
        if (error.message === 'SERVER_RESTART_REQUIRED') {
            empty.className = 'alert alert-danger';
            empty.textContent = '更新前のサーバーが動作しています。Systemaを停止し、run_systema.batから再起動してください。';
        }
    }
}

async function addWatchItem(item) {
    const payload = {
        ...item,
        currentPrice: item.price,
        marketMedian: currentMedianPrice,
        searchKeyword: document.getElementById('search').value.trim(),
    };
    try {
        const response = await fetch('/taskle/watchlist', {
            method: 'POST',
            headers: window.systemaCsrfHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify(payload),
        });
        const result = await response.json();
        if (!response.ok) throw new Error(result.error || `HTTP ${response.status}`);
        await loadWatchlist();
    } catch (error) {
        console.error('ウォッチ登録エラー:', error);
        alert(`ウォッチリストへ追加できませんでした: ${error.message}`);
    }
}

async function removeWatchItem(itemId) {
    try {
        const response = await fetch(`/taskle/watchlist/${itemId}`, {
            method: 'DELETE',
            headers: window.systemaCsrfHeaders(),
        });
        const result = await response.json();
        if (!response.ok) throw new Error(result.error || `HTTP ${response.status}`);
        await loadWatchlist();
    } catch (error) {
        console.error('ウォッチ解除エラー:', error);
        alert(`ウォッチを解除できませんでした: ${error.message}`);
    }
}

function renderWatchlist(items) {
    const table = document.getElementById('watchlistTable');
    const empty = document.getElementById('watchlistEmpty');
    const body = table.querySelector('tbody');
    body.innerHTML = '';
    table.style.display = items.length ? 'table' : 'none';
    empty.style.display = items.length ? 'none' : 'block';

    items.forEach(item => {
        const row = body.insertRow();
        const nameCell = row.insertCell(0);
        const link = document.createElement('a');
        link.href = item.url;
        link.textContent = item.name;
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        nameCell.appendChild(link);
        row.insertCell(1).textContent = `${Number(item.currentPrice).toLocaleString()}円`;
        row.insertCell(2).textContent = `${Number(item.addedPrice).toLocaleString()}円`;
        const change = Number(item.priceChange);
        const changeCell = row.insertCell(3);
        changeCell.textContent = `${change > 0 ? '+' : ''}${change.toLocaleString()}円`;
        changeCell.className = change < 0 ? 'text-success' : change > 0 ? 'text-danger' : '';
        row.insertCell(4).appendChild(createDecisionBadge(item.buyDecision));
        row.insertCell(5).textContent = formatCheckedAt(item.lastCheckedAt);
        const actionCell = row.insertCell(6);
        const removeButton = document.createElement('button');
        removeButton.type = 'button';
        removeButton.className = 'btn btn-sm btn-outline-danger';
        removeButton.textContent = 'ウォッチ解除';
        removeButton.addEventListener('click', () => removeWatchItem(item.id));
        actionCell.appendChild(removeButton);
    });
}

function formatCheckedAt(value) {
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? 'N/A' : date.toLocaleString('ja-JP');
}
